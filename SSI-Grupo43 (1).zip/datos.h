#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <pwd.h>
#include <string.h>
#include <time.h>
#include <dirent.h>



#define NUMUSUARIO 4
#define MAX_GRUPOS 20
#define MAX_NOMBRE 50
#define MAX_USUARIOS 5
#define MAX_MSG 512
#define MAX_LINEA 512

typedef struct {
    char nombre[MAX_NOMBRE];
    char usuarios[MAX_USUARIOS][MAX_NOMBRE];
    char creador[MAX_NOMBRE];
    int num_usuarios;
} Grupo;

extern char *usuarios[NUMUSUARIO];
extern int num_grupo;
extern Grupo grupos[];

