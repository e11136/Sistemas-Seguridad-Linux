/**
 * Funcion destinada a la creacion de la estructura necesaria para 
 * el funcionamiento del programa. Crea una carpeta para cada usuario 
 * del sistema.
 * 
 **/

void activar();

/**
 * Funcion destinada a elimiar todas las estructuras y mensajes creados
 * durante la ejecución del programa.
 * 
 **/
void desactivar ();

/**
 * Funcion destinada listar en que consiste cada funcion para ayudar al 
 * usuario a comprender mejor las funciones.
 * 
 **/
void help ();

/**
 * Funcion destinada a la creación de grupos dentro del programa. 
 * 
 * @param ng nombre del grupo que se desea crear.
 * 
 **/
int crear_grupo(const char *ng);

/**
 * Funcion destinada eliminar un grupo determinado. 
 * 
 * @param ng nombre del grupo que se desea eliminar.
 * 
 * @return 0 si ha salido todo correctamente y -1 si algo a fallado.
 * 
 **/
 
 void agregar_informacio(char *ng);
int eliminar_grupo(const char *ng);

/**
 * Funcion destinada a listar los miembros pertenecientes a un grupo. 
 * 
 * @param nombre_grupo nombre del grupo que se desea crear.
 * 
 **/
void listar_usuarios_grupo(const char *ng);

/**
 * Funcion destinada a listar los miembros pertenecientes a un grupo. 
 * 
 * @param ng nombre del grupo que se desea crear.
 * 
 **/
void anadir_usuario_a_grupo(const char *nombre_usuario) ;

/**
 * Funcion destinada a eliminar un usuario de un grupo. 
 * 
 * @param nombre_usuario nombre del usuario que se desea añadir a mi grupo.
 * 
 **/
void eliminar_usuario_de_grupo(const char *nombre_usuario);


/**
 * Funcion destinada al envio de mensajes entre usuarios, 
 * un usuario invoca la función y se crea el mensaje en un fichero dentro 
 * de la carpeta del usuario destinatario
 * 
 * @param destinatario usuario al que va destinado el mensaje.
 * @param mensaje string en el que se encuentra el contenido del mensaje.
 * 
 **/
void enviar_mensaje(const char *destinatario, const char *mensaje);

/**
 * Funcion que imprime una lista con los mensajes que no han sido leidos
 * del usuario que la invoca.
 * 
 **/
void listar_mensajes_no_leidos();

/**
 * Funcion que imprime una lista con los mensajes del usuario que la invoca.
 * 
 **/
void listar_todos_mensajes();

/**
 * Funcion destinada a mostrar el contenido de un mensaje determinado. 
 * 
 * @param nombre_archivo es el nombre del mensaje que se desea mostrar. 
 * 
 **/
void leer_mensaje(const char *nombre_archivo);

/**
 * Funcion destinada a eliminar un mensaje determinado. 
 * 
 * @param id del mensaje que se desea eliminar. 
 * 
 **/
void remover (char *id);

/**
 * Funcion destinada a actualizar los grupos. 
 * 
 * 
 **/
void actualizar ();

