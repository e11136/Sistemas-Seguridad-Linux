

#include "prototipos.h"
#include "datos.h"

char *usuarios[] = {"alvaro", "carlota", "hugo", "dario"};


int main(int argc, char *argv[]) {
	char comando[20];
    while (1){
		actualizar();
		printf("$-concordia-");
		scanf("%s", comando);
		
		//Funciones destinadas a iniciar y finalizar el programa.
		if (strcmp(comando, "ativar") == 0) {
			activar();
		} else if (strcmp(comando, "exit") == 0){
			return 0;
		} else if (strcmp(comando, "desativar") == 0){
			desactivar();
			return 0;
		
		//Funciones destinadas al manejo de los grupos
		} else if (strcmp(comando, "grupo-criar") == 0){
			printf("Escriba el nombre del grupo: ");
			char nombre_grupo[MAX_NOMBRE];
			scanf("%s", nombre_grupo);
			if(crear_grupo(nombre_grupo)==0){
				printf("Se ha creado el grupo correctamente\n");
			} else {
				printf("Error en la creacion del grupo\n");
			}	
		} else if (strcmp(comando, "grupo-remover") == 0){
			printf("Escriba el nombre del grupo: ");
			char nombre_grupo[MAX_NOMBRE];
			scanf("%s", nombre_grupo);
			if(eliminar_grupo(nombre_grupo)==0){
				printf("Se ha borrado el grupo correctamente\n");
			} else {
				printf("Error en el borrado del grupo\n");
			}		
		} else if (strcmp(comando, "grupo-listar") == 0){
			printf("Escriba el nombre del grupo: ");
			char nombre_grupo[MAX_NOMBRE];
			scanf("%s", nombre_grupo);
			listar_usuarios_grupo(nombre_grupo);			
		} else if (strcmp(comando, "grupo-destinario-adicionar") == 0){
			printf("Escriba el nombre del usuario: ");
			char nombre_usuario[MAX_NOMBRE];
			scanf("%s", nombre_usuario);
			anadir_usuario_a_grupo(nombre_usuario);	
		} else if (strcmp(comando, "grupo-destinario-remover") == 0){
			printf("Escriba el nombre del usuario: ");
			char nombre_usuario[MAX_NOMBRE];
			scanf("%s", nombre_usuario);
			eliminar_usuario_de_grupo(nombre_usuario);
	
		//Funciones destinadas al control de mensajes	
		} else if (strcmp(comando, "enviar") == 0){
			printf("Escriba el destinatario: ");
			char destinatario[MAX_NOMBRE];
			scanf("%s", destinatario);	
			getchar();
			printf("Escriba el mensaje: ");
			char mg[MAX_MSG];
			fgets(mg, sizeof(mg), stdin); // Leer la línea completa desde la entrada estándar
			if (mg[strlen(mg) - 1] == '\n') {
				mg[strlen(mg) - 1] = '\0';
			}
			enviar_mensaje(destinatario, mg);
				
		} else if (strcmp(comando, "ler") == 0){
			printf("Escriba el id del mensaje: ");
			char nombre_archivo[MAX_NOMBRE];
			scanf("%s", nombre_archivo);
			leer_mensaje(nombre_archivo);
		} else if (strcmp(comando, "listar") == 0){
            listar_mensajes_no_leidos();
		} else if (strcmp(comando, "listar-a") == 0){
            listar_todos_mensajes();
        } else if (strcmp(comando, "remover") == 0) {
			printf("Escriba el id del mensaje: ");
			char id[MAX_NOMBRE];
			scanf("%s", id);
			remover (id);
			
        //Funcion de ayuda al usuario
        } else if (strcmp(comando, "help") == 0) {
			help();
        
        //Si el comando no es correcto se informa al usuario
        } else {
			printf("ERROR: Comando Incorrecto\n");
		}
	}
    

    return 0;
}

