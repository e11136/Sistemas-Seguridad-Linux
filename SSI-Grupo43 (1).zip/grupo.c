#include "datos.h"

int num_grupo = 0;

Grupo grupos[MAX_GRUPOS];
int buscar_nombre_grupo(const char *nombreGrupo);

void actualizar() {
    const char *ruta = ".";
    DIR *dir;
    struct dirent *entry;
   

    // Abrir el directorio
    dir = opendir(ruta);
    if (dir == NULL) {
        perror("Error al abrir el directorio");
        return;
    }

    // Recorrer cada entrada en el directorio
    while ((entry = readdir(dir)) != NULL) {
        // Verificar si la entrada es un directorio y empieza por "MG-G"
        if (entry->d_type == DT_DIR && strstr(entry->d_name, "MG-G-") != NULL) {
            int contador = 0;
            FILE *archivo;
            char linea[MAX_MSG];
            int numero_usuarios = 0;
            char nombreGrupo[MAX_NOMBRE];

            // Construir la ruta completa al archivo de información
            char ruta_completa[MAX_MSG];
            snprintf(ruta_completa, sizeof(ruta_completa), "%s/%s/Informacion.txt", ruta, entry->d_name);

            // Abrir el archivo
            archivo = fopen(ruta_completa, "r");
            if (archivo == NULL) {
                perror("Error al abrir el archivo");
                return;
            }
            
			
            // Iterar sobre las líneas del archivo
            while (fgets(linea, MAX_MSG, archivo) != NULL) {
				
                contador++; // Incrementar el contador en cada iteración
                if(strcmp(nombreGrupo, "") == 0){
					if (contador == 1) {
						char *token = strtok(linea, " \t\n");
						if (token != NULL) {
							strcpy(nombreGrupo,token);
						}
					}
				}
				if(buscar_nombre_grupo(nombreGrupo) != 0){
					if (contador == 1) {
						char *token = strtok(linea, " \t\n");
						if (token != NULL) {
							strcpy(grupos[num_grupo].nombre, token);

						}
					} else if (contador == 2) {
						char *token = strtok(linea, " \t\n");
						if (token != NULL) {
							strcpy(grupos[num_grupo].creador, token);
						}
					} else if (contador == 3) {
						char *token = strtok(linea, " \t\n");

						if (token != NULL) {
							grupos[num_grupo].num_usuarios = atoi(token);
						}
					} else if (contador > 3){
						char *token = strtok(linea, " \t\n");
						if (token != NULL) {
							strcpy(grupos[num_grupo].usuarios[numero_usuarios], token);
							numero_usuarios++;
							if(numero_usuarios == grupos[num_grupo].num_usuarios){
								num_grupo++;
							}
						}
					} else {
						printf("ERROR");
					}
					
				}
            }
            
            fclose(archivo);
            
		}
    }
    // Cerrar el directorio
    closedir(dir);    

}



int buscar_nombre_grupo(const char *nombreGrupo){
	for (int i = 0; i <= num_grupo + 1; i++)
	{
		if(strcmp(grupos[i].nombre, nombreGrupo) == 0){
			return 0; //para indicar que fallo
		}
	}
	return -1;
}

void agregar_informacio(const char *ng){
	
	
	char nombre_archivo[MAX_NOMBRE];
    FILE *archivo;
    int indice_grupo;
    
    // Crear el nombre del archivo utilizando el destinatario
    snprintf(nombre_archivo, MAX_MSG, "./MG-G-%s/Informacion.txt", ng);

    archivo = fopen(nombre_archivo, "w");
    if (archivo == NULL) {
        perror("Error al abrir el archivo");
        return;
    }
    
    // Buscar el grupo con el nombre especificado
    for (int i = 0; i < num_grupo; i++) {
        if (strcmp(grupos[i].nombre, ng) == 0) {
            indice_grupo = i;
            break;  // Salir del bucle una vez que se haya encontrado el grupo
        }
    }
    
    // Escribir los datos necesarios en el mensaje (ID, remitente, fecha, contenido)
    fprintf(archivo, "%s\n", grupos[indice_grupo].nombre);
    fprintf(archivo, "%s\n", grupos[indice_grupo].creador);	
    fprintf(archivo, "%d\n", grupos[indice_grupo].num_usuarios);	
    
    for (int i = 0; i < grupos[indice_grupo].num_usuarios; i++) {
		fprintf(archivo, "%s \n", grupos[indice_grupo].usuarios[i]);
	}

    if (fclose(archivo) == EOF) {
        perror("Error al cerrar el archivo");
        return;
    }
	
} 

int crear_grupo(const char *ng){
	Grupo nuevoGrupo;

    //Comprueba que no exista ningun grupo con ese nombre
    for (int i = 0; i < num_grupo; i++)
	{
		if(strcmp(grupos[i].nombre, ng)== 0){
			return -1; //para indicar que fallo
		}
	}
	
	//Incorpora el nuevo grupo todos los parametros necesarios
	
    strcpy(nuevoGrupo.nombre, ng);
    
    char  *usuario_creador = getenv("USER"); 
    
    strcpy(nuevoGrupo.creador, usuario_creador);
    
    nuevoGrupo.num_usuarios = 1;
    
    strcpy(nuevoGrupo.usuarios[0], usuario_creador);
    
	grupos[num_grupo] = nuevoGrupo;
	
	num_grupo++;
	
	//Crea la carpeta donde se almacenaran los mensajes de grupo.
	char carpeta[MAX_NOMBRE];
	snprintf(carpeta, MAX_NOMBRE, "MG-G-%s", ng);
	
	if (mkdir(carpeta, 0777) == 0) {
		printf("La carpeta \"%s\" ha sido creada.\n", carpeta);
	} else {
		printf("Error al crear la carpeta \"%s\".\n", carpeta);
			
	}    
	
	agregar_informacio(ng);   
	
	return 0;
	
}


int eliminar_grupo(char *ng) {
    int indice_grupo_a_eliminar = -1;
	char  *usuario_elegido = getenv("USER"); 
	
    // Buscar el grupo con el nombre especificado
    for (int i = 0; i < num_grupo + 1; i++) {
        if (strcmp(grupos[i].nombre, ng) == 0 && strcmp(grupos[i].creador,usuario_elegido)==0) {
            indice_grupo_a_eliminar = i;
            break;  // Salir del bucle una vez que se haya encontrado el grupo
        }
    }

    // Verificar si se encontró el grupo a eliminar 
    if (indice_grupo_a_eliminar != -1) {
        // Mover todos los grupos siguientes una posición hacia atrás para llenar el espacio del grupo eliminado
        for (int i = indice_grupo_a_eliminar; i < num_grupo - 1; i++) {
            grupos[i] = grupos[i + 1];
        }

        //Decrementar el contador de numero de grupos.
        num_grupo--;

        printf("El grupo %s ha sido eliminado.\n", ng);
    } else {
        printf("El grupo %s no fue encontrado.\n", ng);
        return -1;
    }
    
    char comando[MAX_NOMBRE + 20];
	snprintf(comando, MAX_NOMBRE + 20, "rm -r MG-G-%s", ng);
	if (system(comando) == 0) {
		printf("Se eliminado el grupo.\n");
	} else {
		perror("ERROR al borrar el grupo \n");
		return -1;
	}
	return 0;
}

void listar_usuarios_grupo(const char *ng) {
	
	char  *usuario_elegido = getenv("USER"); 
	
    // Buscar el grupo con el nombre especificado
    for (int i = 0; i < num_grupo + 1; i++) {
        if (strcmp(grupos[i].nombre, ng) == 0 && strcmp(grupos[i].creador,usuario_elegido)==0) {
            printf("Usuarios del grupo %s:\n", ng);
            for (int j = 0; j < grupos[i].num_usuarios; j++) {
                printf("- %s\n", grupos[i].usuarios[j]);
            }
            return;
        }
    }
    // Si el grupo no fue encontrado informa de ello
    printf("El grupo %s no fue encontrado.\n", ng);
}

void anadir_usuario_a_grupo(const char *nombre_usuario) {
    
    // Buscar el grupo con el nombre especificado
    const char *creador = getenv("USER"); 
    int indice_grupo = -1;
    printf("%i",num_grupo);
    for (int i = 0; i < num_grupo + 1; i++) {
		printf("%s",grupos[i].creador);
        if (strcmp(grupos[i].creador, creador) == 0) {
            indice_grupo = i;
            break;
        }
    }
    if (indice_grupo == -1) {
		printf("No es el creador de ningun grupo.\n");
		return;
	}
	
	//controla si el usuario existe en el grupo
    int comprobar = -1; 
    for (int i = 0; i < sizeof(usuarios)/sizeof(usuarios[0]); i++) {
		if (strcmp(usuarios[i], nombre_usuario) == 0) {
			comprobar = 1;
		}
	}
	if (comprobar == -1) {
		printf("Usuario no valido\n");
		return;
	}
    
    // Verificar si el usuario ya está presente en el grupo
    for (int i = 0; i < grupos[indice_grupo].num_usuarios; i++) {
        if (strcmp(grupos[indice_grupo].usuarios[i], nombre_usuario) == 0) {
            printf("El usuario %s ya está presente en el grupo \n", nombre_usuario);
            return;
        }
    }
    
    // Verificar si hay espacio para añadir otro usuario al grupo
    if (grupos[indice_grupo].num_usuarios >= MAX_USUARIOS) {
        printf("El grupo ya tiene el número máximo de usuarios.\n");
        return;
    }
    
    // Añadir el nuevo usuario al grupo
    strcpy(grupos[indice_grupo].usuarios[grupos[indice_grupo].num_usuarios], nombre_usuario);
    grupos[indice_grupo].num_usuarios++;
    
    printf("Se ha añadido el usuario %s al grupo .\n", nombre_usuario);
    
    agregar_informacio(grupos[indice_grupo].nombre); 
}

void eliminar_usuario_de_grupo(const char *nombre_usuario) {
    // Buscar el grupo con el nombre especificado
    const char *creador = getenv("USER");

    int indice_grupo = -1;
    for (int i = 0; i < num_grupo + 1; i++) {
        if (strcmp(grupos[i].creador, creador) == 0) {
            indice_grupo = i;
            break;
        }
    }

    // Verificar si se encontró el grupo
    if (indice_grupo == -1) {
        printf("No se encontró un grupo creado por el usuario.\n");
        return;
    }

    // Verificar si el usuario que realiza la acción es el creador del grupo
    if (strcmp(grupos[indice_grupo].creador, creador) != 0) {
        printf("Solo el creador del grupo puede eliminar usuarios.\n");
        return;
    }

    // Verificar si el usuario está presente en el grupo y eliminarlo si es así
    int usuario_encontrado = 0;
    for (int i = 0; i < grupos[indice_grupo].num_usuarios; i++) {
        if (strcmp(grupos[indice_grupo].usuarios[i], nombre_usuario) == 0) {
            for (int j = i; j < grupos[indice_grupo].num_usuarios - 1; j++) {
                strcpy(grupos[indice_grupo].usuarios[j], grupos[indice_grupo].usuarios[j + 1]);
            }
            grupos[indice_grupo].num_usuarios--;
            usuario_encontrado = 1;
            printf("Se ha eliminado el usuario %s del grupo.\n", nombre_usuario);
            break;
        }
    }

    // Si el usuario no fue encontrado informa de ello
    if (!usuario_encontrado) {
        printf("El usuario %s no está presente en el grupo.\n", nombre_usuario);
    }
    
    agregar_informacio(grupos[indice_grupo].nombre); 
}

