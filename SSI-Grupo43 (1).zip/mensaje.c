#include "datos.h"

int ultimo_id = 0;
char *usuario_elegido;

void activar() {
	
    char *usuario_elegido = getenv("USER");

    // Verificar si el nombre de usuario es válido en linux
    if (usuario_elegido == NULL) {
        printf("Error: No se pudo obtener el nombre de usuario.\n");
        return;
    }
    
    for (int i = 0; i < NUMUSUARIO; i++) {
        printf("Usuario %d: %s\n", i+1, usuarios[i]);
        
		char carpeta[MAX_NOMBRE];
		snprintf(carpeta, MAX_NOMBRE, "MG-%s", usuarios[i]);

		// Verificar si la carpeta ya existe en el directorio
		struct stat st;
		if (stat(carpeta, &st) == 0) {
			if (S_ISDIR(st.st_mode)) {
				printf("La carpeta \"%s\" ya existe.\n", carpeta);
			}
		}

		if (mkdir(carpeta, 0777) == 0) {
			printf("La carpeta \"%s\" ha sido creada.\n", carpeta);
			char comando[MAX_NOMBRE + 20];
			snprintf(comando, MAX_NOMBRE + 20, "sudo chown %s %s", usuarios[i], carpeta);
			if (system(comando) == 0) {
				printf("Se cambió exitosamente el dueño de %s a %s.\n", carpeta, usuarios[i]);
			} else {
				perror("Error al cambiar el dueño");
			
			}	
		} else {
			printf("Error al crear la carpeta \"%s\".\n", carpeta);
		}       
        
    }
}

void help () {
	printf("Comandos Disponibles:\n");
	printf("\n");
	
	printf("concordia-enviar\n");
	printf("		Este comando solicita el usuario al que se quiere enviar el mensaje\n");
	printf("		y el contenido que se desea enviar.\n");
	printf("\n");
	
	printf("concordia-listar\n");
	printf("		Este comando lista tus mensajes no leidos\n");
	printf("		si se escribe tras este comando un [-a] lista todos los mensajes.\n");
	printf("\n");
	
	printf("concordia-remover\n");
	printf("		Este comando elimina un mensaje recivido segun su indice.\n");
	printf("\n");
	
	printf("concordia-grupo-criar\n");
	printf("		Este comando crea un grupo en el que tu eres el creador y por tanto\n");
	printf("		quien puede ejecutar los comandos respecto al grupo creado. Se solicita\n");
	printf("		el nombre del grupo.\n");
	printf("\n");
	
	printf("concordia-grupo-remover\n");
	printf("		Este comando elimina un grupo completo, para ello es necesario que solicite \n");
	printf("		el nombre del grupo.\n");
	printf("		Solo el creador puede eliminar su grupo.\n");
	printf("\n");
	
	printf("concordia-grupo-listar\n");
	printf("		Este comando lista el nombre de todos los usuarios pertenecientes a un grupo \n");
	printf("		determinado para ellos es necesario solicitarlo.\n");
	printf("\n");
	
	printf("concordia-grupo-destinario-adicionar\n");
	printf("		Este comando anhade un usuario a un grupo, para ello solicita el nombre del grupo.\n");
	printf("		Solo el creador puede ahnadir usuarios al grupo.\n");
	printf("\n");
	
	printf("concordia-grupo-destinario-remover\n");
	printf("		Este comando elimina un usuario a un grupo, para ello solicita el nombre del grupo.\n");
	printf("		Solo el creador puede eliminar usuarios del grupo.\n");
	printf("\n");
	
	printf("concordia-activar\n");
	printf("		Este comando crea las estructuras necesarias para la realización del programa.\n");
	printf("		Es necesario que si no ha sido realizada se haga para que todo funcione correctamente.\n");
	printf("\n");
	
	printf("concordia-desactivar\n");
	printf("		Este comando elimina tanto la estructura como los mensajes intercambiados durante\n");
	printf("		la ejecución del programa.\n");
}

void enviar_mensaje(const char *destinatario, const char *mensaje) {
    char nombre_archivo[MAX_NOMBRE];
    FILE *archivo;


    int hay_grupo = -1;
    for (int i = 0; i < num_grupo; i++){
		if(strcmp(grupos[i].nombre, destinatario) == 0){
			hay_grupo = i;
		}
	}


    if(hay_grupo == -1){
		char *remitente;
		remitente = getenv("USER");
		// Crear el nombre del archivo utilizando el destinatario
		snprintf(nombre_archivo, MAX_MSG, "./MG-%s/mensaje_%d.txt",
		destinatario,++ultimo_id);

		// Abrir el archivo en modo de escritura (si no existe, se crea; si existe, se sobrescribe)
		archivo = fopen(nombre_archivo, "w");
		if (archivo == NULL) {
			perror("Error al abrir el archivo");
			return;
		}

		// Obtener la fecha y hora actual
		time_t tiempo_actual = time(NULL);
		char leido[] = "no";
		struct tm *tm_info = localtime(&tiempo_actual);
		char fecha[20];
		strftime(fecha, sizeof(fecha), "%Y-%m-%d %H:%M:%S", tm_info);

		// Escribir los metadatos del mensaje (ID, remitente, fecha, contenido) en el archivo
		fprintf(archivo, "%s\n", leido);//leido
		fprintf(archivo, "%s\n", fecha);//fecha
		fprintf(archivo, "%s\n", remitente);//remitente
		fprintf(archivo, "%s\n", mensaje);//Mensaje

		// Cerrar el archivo después de escribir el mensaje
		if (fclose(archivo) == EOF) {
			perror("Error al cerrar el archivo");
			return;
		}

		// Cambiar el propietario del archivo
		char comando[200]; // Espacio para el comando y los argumentos
		snprintf(comando, 200, "sudo chown %s %s", destinatario, nombre_archivo);
		if (system(comando) == 0) {
			printf("Se cambió exitosamente el dueño de %s a %s.\n",
			nombre_archivo, destinatario);
		} else {
			perror("Error al cambiar el dueño");
		}
		char comando_chown[100];
		sprintf(comando_chown, "sudo chmod 700 %s", nombre_archivo);
		if (system(comando_chown) == -1) {
			perror("Error al establecer los permisos con setfacl");
			exit(EXIT_FAILURE);
		}
	} else {
		for (int i = 0; i < grupos[hay_grupo].num_usuarios; i++){
			char *remitente;
			remitente = getenv("USER");
			// Crear el nombre del archivo utilizando el destinatario
			snprintf(nombre_archivo, MAX_MSG, "./MG-%s/mensaje_grupo_%d.txt",
			grupos[hay_grupo].usuarios[i],++ultimo_id);

			// Abrir el archivo en modo de escritura (si no existe, se crea; si existe, se sobrescribe)
			archivo = fopen(nombre_archivo, "w");
			if (archivo == NULL) {
				perror("Error al abrir el archivo");
				return;
			}

			// Obtener la fecha y hora actual
			time_t tiempo_actual = time(NULL);
			char leido[] = "no";
			struct tm *tm_info = localtime(&tiempo_actual);
			char fecha[20];
			strftime(fecha, sizeof(fecha), "%Y-%m-%d %H:%M:%S", tm_info);

			// Escribir los metadatos del mensaje (ID, remitente, fecha,contenido) en el archivo
			fprintf(archivo, "%s\n", leido);//leido
			fprintf(archivo, "%s\n", fecha);//fecha
			fprintf(archivo, "%s\n", remitente);//remitente
			fprintf(archivo, "%s\n", mensaje);//Mensaje

			// Cerrar el archivo después de escribir el mensaje
			if (fclose(archivo) == EOF) {
				perror("Error al cerrar el archivo");
				return;
			}

			// Cambiar el propietario del archivo
			char comando[200]; // Espacio para el comando y los argumentos
			snprintf(comando, 200, "sudo chown %s %s",
			grupos[hay_grupo].usuarios[i], nombre_archivo);
			if (system(comando) == 0) {
				printf("Se cambió exitosamente el dueño de %s a %s.\n",
				nombre_archivo, grupos[hay_grupo].usuarios[i]);
			} else {
			perror("Error al cambiar el dueño");
			}
			char comando_chown[100];
			sprintf(comando_chown, "sudo chmod 700 %s", nombre_archivo);
			if (system(comando_chown) == -1) {
				perror("Error al establecer los permisos con setfacl");
				exit(EXIT_FAILURE);
			}
		}
	}
}


void listar_mensajes_no_leidos() {
    // Abrir el directorio actual
    char ruta[MAX_MSG];
	char *remitente = getenv("USER");
	if (remitente == NULL) {
        perror("Error al obtener el nombre de usuario");
        return;
    }
    // Construir la ruta completa al archivo
    snprintf(ruta, MAX_MSG, "./MG-%s", remitente);
    DIR *dir = opendir(ruta);
    if (dir == NULL) {
        perror("Error al abrir el directorio");
        return;
    }

    // Obtener la lista de archivos en el directorio
    char *archivos[MAX_NOMBRE];
    int num_archivos = 0;
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
		snprintf(ruta, MAX_MSG, "./MG-%s/%s", remitente,entry->d_name);
		FILE *archivo = fopen(ruta, "r");
		if (archivo == NULL) {
			perror("Error al abrir el archivo");
            continue;  // Continuar con el siguiente archivo
        }
        char linea[MAX_LINEA];
        if (fgets(linea, MAX_LINEA, archivo) != NULL) {
			// Verificar si la primera línea contiene el string deseado
            if (strstr(linea, "no") != NULL) {
				// Si lo contiene, añadir el archivo a la lista
                archivos[num_archivos] = strdup(entry->d_name);
                if (archivos[num_archivos] == NULL) {
                    perror("Error al asignar memoria para el nombre del archivo");
                    fclose(archivo);
                    continue;
                }
                num_archivos++;
            }
        }
        fclose(archivo);
    }

    // Cerrar el directorio
    closedir(dir);

    // Ordenar los nombres de archivos
    //qsort(archivos, num_archivos, sizeof(char *), comparar);

    // Imprimir los nombres de archivos ordenados
    printf("Listado de archivos en el directorio actual:\n");
    for (int i = 0; i < num_archivos; i++) {
        printf("%s\n", archivos[i]);
        free(archivos[i]); // Liberar memoria asignada por strdup
    }
}

void listar_todos_mensajes() {
	
	char ruta[MAX_MSG];
	char *remitente = getenv("USER");
    
    snprintf(ruta, MAX_MSG, "./MG-%s", remitente);
    
    DIR *dir = opendir(ruta);
    if (dir == NULL) {
        perror("Error al abrir el directorio");
        return;
    }

    // Obtener la lista de archivos en el directorio
    char *archivos[MAX_NOMBRE];
    int num_archivos = 0;
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        // Filtrar solo los archivos regulares
            archivos[num_archivos] = strdup(entry->d_name);
            num_archivos++;
    }

    closedir(dir);

    // Ordenar los nombres de archivos por antigüedad
    //qsort(archivos, num_archivos, sizeof(char *), compary7u666ar_por_antiguedad);

    // Imprimir los nombres de archivos ordenados
    printf("Listado de archivos en el directorio actual (ordenados por antigüedad):\n");
    for (int i = 0; i < num_archivos; i++) {
        printf("%s\n", archivos[i]);
        free(archivos[i]); 
    }
}

void marcar_como_leido (char *nombre_archivo) {

    FILE *archivo = fopen(nombre_archivo, "r+");
    
    if (archivo == NULL) {
        printf("Error al abrir el archivo.\n");
        return;
    }

    // Leer la primera línea del archivo
    char buffer[1024];
    if (fgets(buffer, sizeof(buffer), archivo) != NULL) {
        // Calcular la longitud de la nueva primera línea
        int nueva_longitud = strlen("si\n");

        // Posicionar el puntero del archivo al principio
        rewind(archivo);

        // Escribir la nueva primera línea en el archivo
        fwrite("si\n", 1, nueva_longitud, archivo);

        // Si la nueva línea es más corta que la original, llenar el resto con espacios en blanco
        for (int i = nueva_longitud; i < strlen(buffer); ++i) {
            fputc(' ', archivo);
        }
    } else {
        printf("Error al leer el archivo.\n");
    }

    // Cerrar el archivo
    fclose(archivo);

}

void leer_mensaje(char *nombre_archivo){
    FILE *archivo;
    char linea[MAX_MSG];
    int contador = 0;
	char ruta[MAX_MSG];
	char *remitente = getenv("USER");
    
    snprintf(ruta, MAX_MSG, "./MG-%s/%s", remitente, nombre_archivo);

    archivo = fopen(ruta, "r"); 
    if (archivo == NULL) {
        perror("Error al abrir el archivo");
        return;
    }

    // Iterar sobre las líneas del archivo
    while (fgets(linea, MAX_MSG, archivo) != NULL) {
        contador++; // Incrementa el contador en cada iteración

        // Si el contador es igual a 3, imprime la línea y sale del bucle
        if (contador == 4) {
            printf("Contenido de la tercera línea:\n%s", linea);
            break;
        }
    }

    fclose(archivo);
    
    marcar_como_leido (ruta);
}

void remover (char *nombre_archivo) {
	
	char *usuario = getenv("USER");
	
	char comando[MAX_NOMBRE + 20]; 
	snprintf(comando, MAX_NOMBRE + 20, "rm ./MG-%s/%s", usuario, nombre_archivo);
	if (system(comando) == 0) {
		printf("Se elimino el mensaje %s.\n", nombre_archivo);
	} else {
		perror("ERROR al borrar los archivos");
				
	}
}

void desactivar () {
	char comando[MAX_NOMBRE + 20]; 
	snprintf(comando, MAX_NOMBRE + 20, "rm -r MG*");
	if (system(comando) == 0) {
		printf("Se desactivo el programa.\n");
	} else {
		perror("ERROR al borrar los archivos");
				
	}
}
